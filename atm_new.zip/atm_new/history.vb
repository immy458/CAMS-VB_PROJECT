﻿Public Class history
    Private Sub Backbutton_Click(sender As Object, e As EventArgs) Handles backbutton.Click
        Me.Hide()
        transactionlogs.Show()
    End Sub
End Class