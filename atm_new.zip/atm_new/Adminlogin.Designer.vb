﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Adminlogin
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.clearbuttonadmin = New System.Windows.Forms.Button()
        Me.loginbuttonadmin = New System.Windows.Forms.Button()
        Me.pnotextBox2 = New System.Windows.Forms.TextBox()
        Me.pin = New System.Windows.Forms.Label()
        Me.cnotextBox1 = New System.Windows.Forms.TextBox()
        Me.cno = New System.Windows.Forms.Label()
        Me.title = New System.Windows.Forms.Label()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'clearbuttonadmin
        '
        Me.clearbuttonadmin.BackColor = System.Drawing.Color.White
        Me.clearbuttonadmin.FlatAppearance.BorderColor = System.Drawing.Color.White
        Me.clearbuttonadmin.FlatAppearance.BorderSize = 4
        Me.clearbuttonadmin.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.clearbuttonadmin.Font = New System.Drawing.Font("Cooper Black", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.clearbuttonadmin.ForeColor = System.Drawing.Color.Red
        Me.clearbuttonadmin.Location = New System.Drawing.Point(321, 410)
        Me.clearbuttonadmin.Name = "clearbuttonadmin"
        Me.clearbuttonadmin.Size = New System.Drawing.Size(107, 49)
        Me.clearbuttonadmin.TabIndex = 23
        Me.clearbuttonadmin.Text = "CLEAR"
        Me.clearbuttonadmin.UseVisualStyleBackColor = False
        '
        'loginbuttonadmin
        '
        Me.loginbuttonadmin.BackColor = System.Drawing.Color.White
        Me.loginbuttonadmin.FlatAppearance.BorderColor = System.Drawing.Color.White
        Me.loginbuttonadmin.FlatAppearance.BorderSize = 4
        Me.loginbuttonadmin.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.loginbuttonadmin.Font = New System.Drawing.Font("Cooper Black", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.loginbuttonadmin.ForeColor = System.Drawing.Color.ForestGreen
        Me.loginbuttonadmin.Location = New System.Drawing.Point(553, 410)
        Me.loginbuttonadmin.Name = "loginbuttonadmin"
        Me.loginbuttonadmin.Size = New System.Drawing.Size(107, 49)
        Me.loginbuttonadmin.TabIndex = 22
        Me.loginbuttonadmin.Text = "LOGIN"
        Me.loginbuttonadmin.UseVisualStyleBackColor = False
        '
        'pnotextBox2
        '
        Me.pnotextBox2.BackColor = System.Drawing.Color.White
        Me.pnotextBox2.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.pnotextBox2.Location = New System.Drawing.Point(321, 326)
        Me.pnotextBox2.Name = "pnotextBox2"
        Me.pnotextBox2.PasswordChar = Global.Microsoft.VisualBasic.ChrW(42)
        Me.pnotextBox2.Size = New System.Drawing.Size(339, 38)
        Me.pnotextBox2.TabIndex = 21
        '
        'pin
        '
        Me.pin.AutoSize = True
        Me.pin.Font = New System.Drawing.Font("Cooper Std Black", 14.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.pin.ForeColor = System.Drawing.Color.DarkRed
        Me.pin.Location = New System.Drawing.Point(209, 333)
        Me.pin.Name = "pin"
        Me.pin.Size = New System.Drawing.Size(61, 29)
        Me.pin.TabIndex = 20
        Me.pin.Text = "PIN"
        '
        'cnotextBox1
        '
        Me.cnotextBox1.BackColor = System.Drawing.Color.White
        Me.cnotextBox1.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cnotextBox1.Location = New System.Drawing.Point(321, 228)
        Me.cnotextBox1.Name = "cnotextBox1"
        Me.cnotextBox1.Size = New System.Drawing.Size(339, 38)
        Me.cnotextBox1.TabIndex = 19
        '
        'cno
        '
        Me.cno.AutoSize = True
        Me.cno.Font = New System.Drawing.Font("Cooper Std Black", 14.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cno.ForeColor = System.Drawing.Color.DarkRed
        Me.cno.Location = New System.Drawing.Point(176, 235)
        Me.cno.Name = "cno"
        Me.cno.Size = New System.Drawing.Size(123, 29)
        Me.cno.TabIndex = 18
        Me.cno.Text = "Enter ID"
        '
        'title
        '
        Me.title.AutoSize = True
        Me.title.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.title.Font = New System.Drawing.Font("Copperplate Gothic Bold", 22.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.title.ForeColor = System.Drawing.Color.DodgerBlue
        Me.title.Location = New System.Drawing.Point(275, 9)
        Me.title.Name = "title"
        Me.title.Size = New System.Drawing.Size(416, 43)
        Me.title.TabIndex = 17
        Me.title.Text = "Welcome To CAMS"
        Me.title.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'Button1
        '
        Me.Button1.BackColor = System.Drawing.Color.White
        Me.Button1.FlatAppearance.BorderColor = System.Drawing.Color.White
        Me.Button1.FlatAppearance.BorderSize = 4
        Me.Button1.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Button1.Font = New System.Drawing.Font("Corbel", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button1.ForeColor = System.Drawing.Color.ForestGreen
        Me.Button1.Location = New System.Drawing.Point(12, 12)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(159, 46)
        Me.Button1.TabIndex = 24
        Me.Button1.Text = "CLICK FOR CUSTOMER LOGIN"
        Me.Button1.UseVisualStyleBackColor = False
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Label1.Font = New System.Drawing.Font("Corbel", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.White
        Me.Label1.Location = New System.Drawing.Point(373, 133)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(209, 29)
        Me.Label1.TabIndex = 25
        Me.Label1.Text = "EMPLOYEE LOGIN"
        '
        'Adminlogin
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = Global.atm_new.My.Resources.Resources.image2
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(969, 576)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.clearbuttonadmin)
        Me.Controls.Add(Me.loginbuttonadmin)
        Me.Controls.Add(Me.pnotextBox2)
        Me.Controls.Add(Me.pin)
        Me.Controls.Add(Me.cnotextBox1)
        Me.Controls.Add(Me.cno)
        Me.Controls.Add(Me.title)
        Me.Name = "Adminlogin"
        Me.Text = "Adminlogin"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Private WithEvents clearbuttonadmin As Button
    Private WithEvents loginbuttonadmin As Button
    Private WithEvents pnotextBox2 As TextBox
    Private WithEvents pin As Label
    Private WithEvents cnotextBox1 As TextBox
    Private WithEvents cno As Label
    Private WithEvents title As Label
    Private WithEvents Button1 As Button
    Private WithEvents Label1 As Label
End Class
