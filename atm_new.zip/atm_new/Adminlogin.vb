﻿Imports MySql.Data.MySqlClient

Public Class Adminlogin
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Me.Hide()
        Form1.Show()

    End Sub

    Private Sub Clearbuttonadmin_Click(sender As Object, e As EventArgs) Handles clearbuttonadmin.Click
        pnotextBox2.Text = ""
        cnotextBox1.Text = ""
    End Sub

    Private Sub Loginbuttonadmin_Click(sender As Object, e As EventArgs) Handles loginbuttonadmin.Click
        If pnotextBox2.Text = "" Or cnotextBox1.Text = "" Then
            MessageBox.Show("Error!!!!
            Id and Pin No. is required")
        Else
            conn = New MySqlConnection("server=localhost;user id=root;password=1522;database=schematry")
            conn.Open()
            Dim query1 As String

            Dim cmd1 As MySqlCommand
            Dim reader1 As MySqlDataReader

            query1 = "select * from employee where Eid ='" & cnotextBox1.Text & "' and Pin='" & pnotextBox2.Text & "'"
            cmd1 = New MySqlCommand(query1, conn)
            reader1 = cmd1.ExecuteReader
            If reader1.Read = True Then
                empid = cnotextBox1.Text

                cnotextBox1.Text = ""
                pnotextBox2.Text = ""
                empname = reader1.GetValue(1)
                Me.Hide()
                Adminwelcomeform.Show()
                Adminwelcomeform.welcome.Text = (String.Format("Welcome {0}", reader1.GetValue(1)).ToString())

                reader1.Close()
            Else
                MsgBox("Error!!!! Invalid Card No./Pin No.", MsgBoxStyle.Critical)
                cnotextBox1.Text = ""
                pnotextBox2.Text = ""

            End If
        End If
    End Sub
End Class