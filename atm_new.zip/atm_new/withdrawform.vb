﻿Imports MySql.Data.MySqlClient

Public Class withdrawform
    Private Sub Backbutton_Click(sender As Object, e As EventArgs) Handles backbutton.Click
        Me.Hide()
        Form2.Show()
    End Sub

    Private Sub Proceedbutton_Click(sender As Object, e As EventArgs) Handles proceedbutton.Click
        Dim bal As Integer
        If (amounttextbox.Text = "") Then
            MessageBox.Show("Please enter amount!!")



        Else
            bal = amounttextbox.Text

        If ((bal <= 0)) Then
                MsgBox("Amount cannot be less than or equal to 0", MsgBoxStyle.OkOnly, "Invalid Amount")

            ElseIf (((bal Mod 100) <> 0)) Then
                MsgBox("Amount should be in multiples of 100", MsgBoxStyle.OkOnly, "Invalid Amount")

            Else
            Dim query2 As String
            Dim query1 As String
            Dim cmd1 As MySqlCommand
            Dim cmd2 As MySqlCommand
            '--------------- --------check balance in system------------------------------------------
            Dim query3 As String
            Dim cmd3 As MySqlCommand
            Dim reader3 As MySqlDataReader
            Dim sysbalance As Integer
            query3 = "select * from cams where Sys_id ='" & sysid & "'"
            cmd3 = New MySqlCommand(query3, conn)
            reader3 = cmd3.ExecuteReader
            If reader3.Read = True Then
                sysbalance = reader3.GetValue(2)
                reader3.Close()
            End If

            If (bal > sysbalance) Then

                    MsgBox("Insufficient balance in the machine!!!!", MsgBoxStyle.OkOnly, "Error")

                    amounttextbox.Text = ""
                Me.Hide()
                Form2.Show()
            Else

                Dim reader1 As MySqlDataReader
                Dim reader2 As MySqlDataReader

                Dim accbalance As Integer
                query1 = "select * from account where C_id ='" & c_id & "'"
                cmd1 = New MySqlCommand(query1, conn)
                reader1 = cmd1.ExecuteReader
                Dim newsysbalance As Integer

                If reader1.Read = True Then
                    accbalance = reader1.GetValue(3)
                    reader1.Close()
                    If (bal > accbalance) Then
                            '       MessageBox.Show("Insuffiecient balance!!!!")
                            MsgBox("Insufficient balance in the account!!!!", MsgBoxStyle.OkOnly, "Error")


                        ElseIf (bal < accbalance) Then
                        accbalance = accbalance - bal
                        newsysbalance = sysbalance - bal
                        query2 = "update account set Balance='" & accbalance & "' where C_id ='" & c_id & "'"
                        query3 = "update cams set Balance='" & newsysbalance & "' where Sys_id ='" & sysid & "'"
                        cmd3 = New MySqlCommand(query3, conn)
                        reader3 = cmd3.ExecuteReader
                        reader3.Close()
                        cmd2 = New MySqlCommand(query2, conn)
                        reader2 = cmd2.ExecuteReader

                        reader2.Close()
                        amounttextbox.Text = ""


                            MsgBox("Amount Withdrawn Successfully", MsgBoxStyle.OkOnly, "Success")


                            '-----------------------------------insert into operates---------------------------------------------------------------

                            Dim time As DateTime = DateTime.Now
                        Dim mode As String = "Withdraw"
                        Dim oid As Integer = 100
                        Randomize()
                        Dim i As Integer = CInt(Int((55 * Rnd()) + 8))
                        Dim randomvalue1 As Integer = CInt(Int((999 * Rnd()) + 222))       'generate random numbers between 11 and 99
                        oid = (oid + randomvalue1 + i)
                        query2 = "insert into operates(O_id,C_id,A_no,Sys_id,Time,Mode) values('" & oid & "','" & c_id & "','" & ac_no & "','" & sysid & "','" & time.ToString() & "','" & mode & "')"
                        cmd1 = New MySqlCommand(query2, conn)
                        reader1 = cmd1.ExecuteReader
                        reader1.Close()

                        '--------------------------------------------------insert into withdraw--------------------------------------------------
                        Dim wtid As Integer = 1000
                        Randomize()
                        Dim randomvalue As Integer = CInt(Int((999 * Rnd()) + 111))       'generate random numbers between 111 and 999
                        Dim i1 As Integer = CInt(Int((55 * Rnd()) + 8))

                        wtid = (wtid + randomvalue + i1)
                        Dim date1 As DateTime = DateTime.Now
                        query2 = "insert into withdraw(WT_id,Time,AmountWithdrawn,Date) values('" & wtid & "','" & Now.ToLongTimeString() & "','" & bal & "','" & date1.ToString("yyyy-MM-dd") & "')"
                        cmd1 = New MySqlCommand(query2, conn)
                        reader1 = cmd1.ExecuteReader
                        reader1.Close()

                        '--------------------------------------------------------insert into performs------------------------------------------------
                        Dim pid As Integer = 500
                        Randomize()
                        Dim i2 As Integer = CInt(Int((99 * Rnd()) + 8))

                        Dim pidrandomvalue As Integer = CInt(Int((999 * Rnd()) + 111))       'generate random numbers between 111 and 999
                        pid = (pid + pidrandomvalue + i2)
                        '   query2 = "insert into performs(Sys_id,WT_id,pid,C_id) values('" & sysid & "','" & wtid & "','" & pid & "','" & c_id & "')"
                        query2 = "insert into performs(pid,Sys_id,C_id,WT_id) values('" & pid & "','" & sysid & "','" & c_id & "','" & wtid & "')"

                        cmd1 = New MySqlCommand(query2, conn)
                        reader1 = cmd1.ExecuteReader
                        reader1.Close()

                        Me.Hide()
                        Form2.Show()
                    End If

                End If
            End If


            End If
        End If


    End Sub
End Class