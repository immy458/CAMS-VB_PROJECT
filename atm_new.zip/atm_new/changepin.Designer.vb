﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class changepin
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.welcome = New System.Windows.Forms.Label()
        Me.newpin = New System.Windows.Forms.TextBox()
        Me.pin = New System.Windows.Forms.Label()
        Me.currentpin = New System.Windows.Forms.TextBox()
        Me.cno = New System.Windows.Forms.Label()
        Me.backbutton = New System.Windows.Forms.Button()
        Me.proceedbutton = New System.Windows.Forms.Button()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'welcome
        '
        Me.welcome.AutoSize = True
        Me.welcome.Font = New System.Drawing.Font("Copperplate Gothic Bold", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.welcome.ForeColor = System.Drawing.Color.DarkOrange
        Me.welcome.Location = New System.Drawing.Point(239, 80)
        Me.welcome.Name = "welcome"
        Me.welcome.Size = New System.Drawing.Size(122, 31)
        Me.welcome.TabIndex = 13
        Me.welcome.Text = "label1"
        Me.welcome.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'newpin
        '
        Me.newpin.BackColor = System.Drawing.Color.White
        Me.newpin.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.newpin.Location = New System.Drawing.Point(378, 317)
        Me.newpin.Name = "newpin"
        Me.newpin.Size = New System.Drawing.Size(339, 38)
        Me.newpin.TabIndex = 18
        '
        'pin
        '
        Me.pin.AutoSize = True
        Me.pin.Font = New System.Drawing.Font("Copperplate Gothic Bold", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.pin.ForeColor = System.Drawing.Color.DarkRed
        Me.pin.Location = New System.Drawing.Point(221, 326)
        Me.pin.Name = "pin"
        Me.pin.Size = New System.Drawing.Size(131, 26)
        Me.pin.TabIndex = 17
        Me.pin.Text = "NEW PIN"
        '
        'currentpin
        '
        Me.currentpin.BackColor = System.Drawing.Color.White
        Me.currentpin.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.currentpin.Location = New System.Drawing.Point(378, 233)
        Me.currentpin.Name = "currentpin"
        Me.currentpin.Size = New System.Drawing.Size(339, 38)
        Me.currentpin.TabIndex = 16
        '
        'cno
        '
        Me.cno.AutoSize = True
        Me.cno.Font = New System.Drawing.Font("Copperplate Gothic Bold", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cno.ForeColor = System.Drawing.Color.DarkRed
        Me.cno.Location = New System.Drawing.Point(154, 242)
        Me.cno.Name = "cno"
        Me.cno.Size = New System.Drawing.Size(198, 26)
        Me.cno.TabIndex = 15
        Me.cno.Text = "CURRENT PIN"
        '
        'backbutton
        '
        Me.backbutton.BackColor = System.Drawing.Color.White
        Me.backbutton.FlatAppearance.BorderColor = System.Drawing.Color.White
        Me.backbutton.FlatAppearance.BorderSize = 4
        Me.backbutton.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.backbutton.Font = New System.Drawing.Font("Cooper Black", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.backbutton.ForeColor = System.Drawing.Color.Red
        Me.backbutton.Location = New System.Drawing.Point(378, 419)
        Me.backbutton.Name = "backbutton"
        Me.backbutton.Size = New System.Drawing.Size(107, 49)
        Me.backbutton.TabIndex = 20
        Me.backbutton.Text = "GO BACK"
        Me.backbutton.UseVisualStyleBackColor = False
        '
        'proceedbutton
        '
        Me.proceedbutton.BackColor = System.Drawing.Color.White
        Me.proceedbutton.FlatAppearance.BorderColor = System.Drawing.Color.White
        Me.proceedbutton.FlatAppearance.BorderSize = 4
        Me.proceedbutton.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.proceedbutton.Font = New System.Drawing.Font("Cooper Black", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.proceedbutton.ForeColor = System.Drawing.Color.ForestGreen
        Me.proceedbutton.Location = New System.Drawing.Point(610, 419)
        Me.proceedbutton.Name = "proceedbutton"
        Me.proceedbutton.Size = New System.Drawing.Size(107, 49)
        Me.proceedbutton.TabIndex = 19
        Me.proceedbutton.Text = "PROCEED"
        Me.proceedbutton.UseVisualStyleBackColor = False
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Label2.Font = New System.Drawing.Font("Copperplate Gothic Bold", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.GhostWhite
        Me.Label2.Location = New System.Drawing.Point(422, 149)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(232, 34)
        Me.Label2.TabIndex = 32
        Me.Label2.Text = "CHANGE PIN"
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label1
        '
        Me.Label1.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Label1.Font = New System.Drawing.Font("Copperplate Gothic Bold", 19.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.DodgerBlue
        Me.Label1.Location = New System.Drawing.Point(436, 9)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(158, 38)
        Me.Label1.TabIndex = 47
        Me.Label1.Text = "C A M S"
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'changepin
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = Global.atm_new.My.Resources.Resources.image2
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(969, 576)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.backbutton)
        Me.Controls.Add(Me.proceedbutton)
        Me.Controls.Add(Me.newpin)
        Me.Controls.Add(Me.pin)
        Me.Controls.Add(Me.currentpin)
        Me.Controls.Add(Me.cno)
        Me.Controls.Add(Me.welcome)
        Me.Name = "changepin"
        Me.Text = "Form3"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents welcome As Label
    Private WithEvents newpin As TextBox
    Private WithEvents pin As Label
    Private WithEvents currentpin As TextBox
    Private WithEvents cno As Label
    Private WithEvents backbutton As Button
    Private WithEvents proceedbutton As Button
    Friend WithEvents Label2 As Label
    Friend WithEvents Label1 As Label
End Class
