﻿Imports MySql.Data.MySqlClient

Public Class employeewithdrawform
    Private Sub Backbutton_Click(sender As Object, e As EventArgs) Handles backbutton.Click
        Me.Hide()
        Adminwelcomeform.Show()

    End Sub

    Private Sub Proceedbutton_Click(sender As Object, e As EventArgs) Handles proceedbutton.Click
        Dim bal As Integer
        If (amounttextbox.Text = "") Then
            MessageBox.Show("Please enter amount!!")
        Else

            bal = amounttextbox.Text

            If ((bal <= 0)) Then
                MsgBox("Amount cannot be less than or equal to 0", MsgBoxStyle.OkOnly, "Invalid Amount")

            ElseIf (((bal Mod 100) <> 0)) Then
                MsgBox("Amount should be in multiples of 100", MsgBoxStyle.OkOnly, "Invalid Amount")
            Else
                Dim query2 As String
                Dim query1 As String
                Dim cmd1 As MySqlCommand
                Dim cmd2 As MySqlCommand
                Dim reader2 As MySqlDataReader
                Dim reader1 As MySqlDataReader

                '--------------- --------check balance in system------------------------------------------
                Dim query3 As String
                Dim cmd3 As MySqlCommand
                Dim reader3 As MySqlDataReader
                Dim sysbalance As Integer
                query3 = "select * from cams where Sys_id ='" & sysid & "'"
                cmd3 = New MySqlCommand(query3, conn)
                reader3 = cmd3.ExecuteReader
                If reader3.Read = True Then
                    sysbalance = reader3.GetValue(2)
                    reader3.Close()
                End If

                If (bal > sysbalance) Then
                    MsgBox("Insufficient balance in the machine!!!!", MsgBoxStyle.OkOnly, "Error")
                    amounttextbox.Text = ""
                    Me.Hide()
                    Adminwelcomeform.Show()
                Else
                    sysbalance = sysbalance - bal
                    query2 = "update cams set Balance='" & sysbalance & "' where Sys_id ='" & sysid & "'"
                    cmd2 = New MySqlCommand(query2, conn)
                    reader2 = cmd2.ExecuteReader
                    reader2.Close()
                    amounttextbox.Text = ""

                    MsgBox("Amount Withdrawn Successfully", MsgBoxStyle.OkOnly, "Success")

                    '-------------------------------------INSERT INTO MANAGED BY--------------------------------

                    Dim time As DateTime = DateTime.Now
                    Dim mode As String = "Withdraw"
                    Dim mid As Integer = 100
                    Randomize()
                    Dim i As Integer = CInt(Int((2000 * Rnd()) + 1000))

                    Dim randomvalue1 As Integer = CInt(Int((999 * Rnd()) + 222))       'generate random numbers between 222 and 999
                    mid = (mid + randomvalue1 + i)
                    query2 = "insert into managed_by(mid,Sys_id,Eid,Time,Mode) values('" & mid & "','" & sysid & "','" & empid & "','" & time.ToString() & "','" & mode & "')"
                    cmd1 = New MySqlCommand(query2, conn)
                    reader1 = cmd1.ExecuteReader
                    reader1.Close()

                    Me.Hide()
                    Adminwelcomeform.Show()
                End If
            End If
        End If


    End Sub
End Class