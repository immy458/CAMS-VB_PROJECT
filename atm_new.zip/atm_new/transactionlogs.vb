﻿Imports MySql.Data.MySqlClient
Public Class transactionlogs
    Private Sub Withdrawhistory_Click(sender As Object, e As EventArgs) Handles Withdrawhistory.Click


        Me.Hide()
        history.Show()
        history.welcome.Text = (String.Format("Welcome {0}", custname).ToString())
        history.Label.Text = "WITHDRAWAL HISTORY"

        Dim reader1 As MySqlDataReader
        Dim sda As New MySqlDataAdapter
        Dim cmd1 As MySqlCommand
        Dim dbDataSet As New DataTable
        Dim bsource As New BindingSource
        query = "select w.WT_id,AmountWithdrawn,Time,Date from withdraw as w,performs as p where p.C_id='" & c_id & "' and w.WT_id=p.WT_id order by Date,Time"
        cmd1 = New MySqlCommand(query, conn)
        reader1 = cmd1.ExecuteReader
        If reader1.Read = True Then
            history.Label22.Visible = False
            history.DataGridView1.Visible = True
            sda.SelectCommand = cmd1
            reader1.Close()
            sda.Fill(dbDataSet)
            bsource.DataSource = dbDataSet
            history.DataGridView1.DataSource = bsource
            sda.Update(dbDataSet)
        Else
            history.Label22.Visible = True
            history.DataGridView1.Visible = False
            history.Label22.Text = "No Withdraw Transaction has been performed"
        End If


    End Sub

    Private Sub Deposithistory_Click(sender As Object, e As EventArgs) Handles deposithistory.Click

        Me.Hide()
        history.Show()
        history.welcome.Text = (String.Format("Welcome {0}", custname).ToString())
        history.Label.Text = "DEPOSIT HISTORY"
        '  Dim query1 As String

        Dim reader1 As MySqlDataReader
        Dim sda As New MySqlDataAdapter
        Dim cmd1 As MySqlCommand
        Dim dbDataSet As New DataTable
        Dim bsource As New BindingSource
        query = "select d.Deposit_id,AmountDeposited,Time,Date from deposit as d,performs as p where p.C_id='" & c_id & "' and d.Deposit_id=p.Deposit_id order by Date,Time"
        cmd1 = New MySqlCommand(query, conn)
        reader1 = cmd1.ExecuteReader
        If reader1.Read = True Then
            history.Label22.Visible = False
            history.DataGridView1.Visible = True
            sda.SelectCommand = cmd1
            reader1.Close()
            sda.Fill(dbDataSet)
            bsource.DataSource = dbDataSet
            history.DataGridView1.DataSource = bsource
            sda.Update(dbDataSet)
        Else
            history.Label22.Visible = True
            history.DataGridView1.Visible = False
            history.Label22.Text = "No Deposit Transaction has been performed"
        End If
    End Sub

    Private Sub Backbutton_Click(sender As Object, e As EventArgs) Handles backbutton.Click
        Me.Hide()
        Form2.Show()

    End Sub

    Private Sub Transferhistory_Click(sender As Object, e As EventArgs) Handles transferhistory.Click

        Me.Hide()
        history.Show()
        history.welcome.Text = (String.Format("Welcome {0}", custname).ToString())
        history.Label.Text = "TRANSFER HISTORY"
        '  Dim query1 As String

        Dim reader1 As MySqlDataReader
        Dim sda As New MySqlDataAdapter
        Dim cmd1 As MySqlCommand
        Dim dbDataSet As New DataTable
        Dim bsource As New BindingSource
        query = "select t.Transfer_id,AmountTransferred,Time,Date,TransferredToAcNo from transfer as t,performs as p where p.C_id='" & c_id & "' and t.Transfer_id=p.Transfer_id order by Date,Time"
        cmd1 = New MySqlCommand(query, conn)
        reader1 = cmd1.ExecuteReader
        If reader1.Read = True Then
            history.Label22.Visible = False
            history.DataGridView1.Visible = True
            sda.SelectCommand = cmd1
            reader1.Close()
            sda.Fill(dbDataSet)
            bsource.DataSource = dbDataSet
            history.DataGridView1.DataSource = bsource
            sda.Update(dbDataSet)
        Else
            history.Label22.Visible = True
            history.DataGridView1.Visible = False
            history.Label22.Text = "No Transfer Transaction has been performed"
        End If

    End Sub

    Private Sub Transactionlogs_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class