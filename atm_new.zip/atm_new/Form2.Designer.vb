﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form2
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.welcome = New System.Windows.Forms.Label()
        Me.accno = New System.Windows.Forms.Label()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Withdraw = New System.Windows.Forms.Button()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.Button4 = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.logs = New System.Windows.Forms.Button()
        Me.Button5 = New System.Windows.Forms.Button()
        Me.logoutbutton = New System.Windows.Forms.Button()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'welcome
        '
        Me.welcome.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.welcome.AutoSize = True
        Me.welcome.Font = New System.Drawing.Font("Copperplate Gothic Bold", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.welcome.ForeColor = System.Drawing.Color.DarkOrange
        Me.welcome.Location = New System.Drawing.Point(251, 82)
        Me.welcome.Name = "welcome"
        Me.welcome.Size = New System.Drawing.Size(126, 31)
        Me.welcome.TabIndex = 0
        Me.welcome.Text = "Label1"
        Me.welcome.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'accno
        '
        Me.accno.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.accno.AutoSize = True
        Me.accno.Font = New System.Drawing.Font("Copperplate Gothic Bold", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.accno.ForeColor = System.Drawing.SystemColors.HotTrack
        Me.accno.Location = New System.Drawing.Point(30, 139)
        Me.accno.Name = "accno"
        Me.accno.Size = New System.Drawing.Size(108, 26)
        Me.accno.TabIndex = 2
        Me.accno.Text = "Label1"
        Me.accno.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'Button1
        '
        Me.Button1.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button1.Font = New System.Drawing.Font("Copperplate Gothic Bold", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button1.ForeColor = System.Drawing.SystemColors.HotTrack
        Me.Button1.Location = New System.Drawing.Point(57, 248)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(182, 53)
        Me.Button1.TabIndex = 3
        Me.Button1.Text = "BALANCE INQUIRY"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Withdraw
        '
        Me.Withdraw.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Withdraw.Font = New System.Drawing.Font("Copperplate Gothic Bold", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Withdraw.ForeColor = System.Drawing.SystemColors.HotTrack
        Me.Withdraw.Location = New System.Drawing.Point(663, 248)
        Me.Withdraw.Name = "Withdraw"
        Me.Withdraw.Size = New System.Drawing.Size(198, 53)
        Me.Withdraw.TabIndex = 9
        Me.Withdraw.Text = "CASH WITHDRAWAL"
        Me.Withdraw.UseVisualStyleBackColor = True
        '
        'Button3
        '
        Me.Button3.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button3.Font = New System.Drawing.Font("Copperplate Gothic Bold", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button3.ForeColor = System.Drawing.SystemColors.HotTrack
        Me.Button3.Location = New System.Drawing.Point(57, 344)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(182, 53)
        Me.Button3.TabIndex = 10
        Me.Button3.Text = "PIN CHANGE"
        Me.Button3.UseVisualStyleBackColor = True
        '
        'Button4
        '
        Me.Button4.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button4.Font = New System.Drawing.Font("Copperplate Gothic Bold", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button4.ForeColor = System.Drawing.SystemColors.HotTrack
        Me.Button4.Location = New System.Drawing.Point(663, 344)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(198, 53)
        Me.Button4.TabIndex = 11
        Me.Button4.Text = "FUND TRANSFER"
        Me.Button4.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.Label1.Font = New System.Drawing.Font("Copperplate Gothic Bold", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.MidnightBlue
        Me.Label1.Location = New System.Drawing.Point(229, 188)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(463, 26)
        Me.Label1.TabIndex = 12
        Me.Label1.Text = "PLEASE SELECT A TRANSACTION"
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'logs
        '
        Me.logs.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.logs.Font = New System.Drawing.Font("Copperplate Gothic Bold", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.logs.ForeColor = System.Drawing.SystemColors.HotTrack
        Me.logs.Location = New System.Drawing.Point(57, 439)
        Me.logs.Name = "logs"
        Me.logs.Size = New System.Drawing.Size(182, 53)
        Me.logs.TabIndex = 13
        Me.logs.Text = "Transaction Logs"
        Me.logs.UseVisualStyleBackColor = True
        '
        'Button5
        '
        Me.Button5.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button5.Font = New System.Drawing.Font("Copperplate Gothic Bold", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button5.ForeColor = System.Drawing.SystemColors.HotTrack
        Me.Button5.Location = New System.Drawing.Point(663, 439)
        Me.Button5.Name = "Button5"
        Me.Button5.Size = New System.Drawing.Size(198, 53)
        Me.Button5.TabIndex = 14
        Me.Button5.Text = "CASH DEPOSIT"
        Me.Button5.UseVisualStyleBackColor = True
        '
        'logoutbutton
        '
        Me.logoutbutton.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.logoutbutton.BackColor = System.Drawing.Color.White
        Me.logoutbutton.FlatAppearance.BorderColor = System.Drawing.Color.White
        Me.logoutbutton.FlatAppearance.BorderSize = 4
        Me.logoutbutton.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.logoutbutton.Font = New System.Drawing.Font("Cooper Black", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.logoutbutton.ForeColor = System.Drawing.Color.Red
        Me.logoutbutton.Location = New System.Drawing.Point(397, 514)
        Me.logoutbutton.Name = "logoutbutton"
        Me.logoutbutton.Size = New System.Drawing.Size(123, 49)
        Me.logoutbutton.TabIndex = 16
        Me.logoutbutton.Text = "LOG OUT"
        Me.logoutbutton.UseVisualStyleBackColor = False
        '
        'Label2
        '
        Me.Label2.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label2.AutoSize = True
        Me.Label2.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Label2.Font = New System.Drawing.Font("Copperplate Gothic Bold", 19.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.DodgerBlue
        Me.Label2.Location = New System.Drawing.Point(392, 9)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(158, 38)
        Me.Label2.TabIndex = 17
        Me.Label2.Text = "C A M S"
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'Form2
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = Global.atm_new.My.Resources.Resources.image2
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(938, 576)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.logoutbutton)
        Me.Controls.Add(Me.Button5)
        Me.Controls.Add(Me.logs)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.Button4)
        Me.Controls.Add(Me.Button3)
        Me.Controls.Add(Me.Withdraw)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.accno)
        Me.Controls.Add(Me.welcome)
        Me.Name = "Form2"
        Me.Text = "Form2"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents welcome As Label
    Friend WithEvents accno As Label
    Friend WithEvents Button1 As Button
    Friend WithEvents Withdraw As Button
    Friend WithEvents Button3 As Button
    Friend WithEvents Button4 As Button
    Friend WithEvents Label1 As Label
    Friend WithEvents logs As Button
    Friend WithEvents Button5 As Button
    Private WithEvents logoutbutton As Button
    Friend WithEvents Label2 As Label
End Class
