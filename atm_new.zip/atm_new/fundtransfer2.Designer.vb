﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class fundtransfer2
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.backbutton = New System.Windows.Forms.Button()
        Me.proceedbutton = New System.Windows.Forms.Button()
        Me.cno = New System.Windows.Forms.Label()
        Me.welcome = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.transfername = New System.Windows.Forms.Label()
        Me.amt = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'backbutton
        '
        Me.backbutton.BackColor = System.Drawing.Color.White
        Me.backbutton.FlatAppearance.BorderColor = System.Drawing.Color.White
        Me.backbutton.FlatAppearance.BorderSize = 4
        Me.backbutton.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.backbutton.Font = New System.Drawing.Font("Cooper Black", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.backbutton.ForeColor = System.Drawing.Color.Red
        Me.backbutton.Location = New System.Drawing.Point(223, 426)
        Me.backbutton.Name = "backbutton"
        Me.backbutton.Size = New System.Drawing.Size(107, 49)
        Me.backbutton.TabIndex = 34
        Me.backbutton.Text = "DECLINE"
        Me.backbutton.UseVisualStyleBackColor = False
        '
        'proceedbutton
        '
        Me.proceedbutton.BackColor = System.Drawing.Color.White
        Me.proceedbutton.FlatAppearance.BorderColor = System.Drawing.Color.White
        Me.proceedbutton.FlatAppearance.BorderSize = 4
        Me.proceedbutton.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.proceedbutton.Font = New System.Drawing.Font("Cooper Black", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.proceedbutton.ForeColor = System.Drawing.Color.ForestGreen
        Me.proceedbutton.Location = New System.Drawing.Point(636, 426)
        Me.proceedbutton.Name = "proceedbutton"
        Me.proceedbutton.Size = New System.Drawing.Size(107, 49)
        Me.proceedbutton.TabIndex = 33
        Me.proceedbutton.Text = "CONFIRM"
        Me.proceedbutton.UseVisualStyleBackColor = False
        '
        'cno
        '
        Me.cno.AutoSize = True
        Me.cno.BackColor = System.Drawing.SystemColors.HighlightText
        Me.cno.Font = New System.Drawing.Font("Copperplate Gothic Bold", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cno.ForeColor = System.Drawing.Color.DarkRed
        Me.cno.Location = New System.Drawing.Point(102, 174)
        Me.cno.Name = "cno"
        Me.cno.Size = New System.Drawing.Size(712, 26)
        Me.cno.TabIndex = 31
        Me.cno.Text = "Confirm Name and Amount To Proceed Transaction"
        '
        'welcome
        '
        Me.welcome.AutoSize = True
        Me.welcome.Font = New System.Drawing.Font("Copperplate Gothic Bold", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.welcome.ForeColor = System.Drawing.Color.DarkOrange
        Me.welcome.Location = New System.Drawing.Point(217, 80)
        Me.welcome.Name = "welcome"
        Me.welcome.Size = New System.Drawing.Size(126, 31)
        Me.welcome.TabIndex = 29
        Me.welcome.Text = "Label1"
        Me.welcome.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Copperplate Gothic Bold", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.Black
        Me.Label2.Location = New System.Drawing.Point(330, 264)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(0, 26)
        Me.Label2.TabIndex = 35
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'transfername
        '
        Me.transfername.AutoSize = True
        Me.transfername.Font = New System.Drawing.Font("Copperplate Gothic Bold", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.transfername.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.transfername.Location = New System.Drawing.Point(362, 255)
        Me.transfername.Name = "transfername"
        Me.transfername.Size = New System.Drawing.Size(108, 26)
        Me.transfername.TabIndex = 36
        Me.transfername.Text = "Label2"
        Me.transfername.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'amt
        '
        Me.amt.AutoSize = True
        Me.amt.Font = New System.Drawing.Font("Copperplate Gothic Bold", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.amt.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.amt.Location = New System.Drawing.Point(362, 324)
        Me.amt.Name = "amt"
        Me.amt.Size = New System.Drawing.Size(108, 26)
        Me.amt.TabIndex = 37
        Me.amt.Text = "Label2"
        Me.amt.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'Label3
        '
        Me.Label3.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label3.AutoSize = True
        Me.Label3.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Label3.Font = New System.Drawing.Font("Copperplate Gothic Bold", 19.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.Color.DodgerBlue
        Me.Label3.Location = New System.Drawing.Point(421, 9)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(158, 38)
        Me.Label3.TabIndex = 38
        Me.Label3.Text = "C A M S"
        Me.Label3.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'fundtransfer2
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = Global.atm_new.My.Resources.Resources.image2
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(969, 576)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.amt)
        Me.Controls.Add(Me.transfername)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.backbutton)
        Me.Controls.Add(Me.proceedbutton)
        Me.Controls.Add(Me.cno)
        Me.Controls.Add(Me.welcome)
        Me.Name = "fundtransfer2"
        Me.Text = "Form3"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Private WithEvents backbutton As Button
    Private WithEvents proceedbutton As Button
    Private WithEvents cno As Label
    Friend WithEvents welcome As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents transfername As Label
    Friend WithEvents amt As Label
    Friend WithEvents Label3 As Label
End Class
