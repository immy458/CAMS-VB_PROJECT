﻿Imports System.Data
Imports System.Data.SqlClient
Imports MySql.Data.MySqlClient




Public Class Form1
    Private Sub Loginbutton_Click(sender As Object, e As EventArgs) Handles loginbutton.Click
        If pnotextBox2.Text = "" Or cnotextBox1.Text = "" Then
            MessageBox.Show("Error!!!!
            Card No. and Pin No. is required")
        Else
            conn = New MySqlConnection("server=localhost;user id=root;password=1522;database=schematry")
            conn.Open()
            query = "select * from customer_details where C_id ='" & cnotextBox1.Text & "' and C_pin='" & pnotextBox2.Text & "'"
            cmd = New MySqlCommand(query, conn)
            reader = cmd.ExecuteReader
            If reader.Read = True Then
                user = cnotextBox1.Text
                Me.Hide()
                reader.Close()

                Dim query1 As String
                Dim cmd1 As MySqlCommand
                Dim reader1 As MySqlDataReader
                query1 = "select * from account where C_id ='" & cnotextBox1.Text & "'"
                cmd1 = New MySqlCommand(query1, conn)
                reader1 = cmd1.ExecuteReader
                If reader1.Read = True Then
                    Form2.Show()
                    Form2.welcome.Text = (String.Format("Welcome {0}", reader1.GetValue(1)).ToString())
                    '   Form2.surname.Text = (String.Format("{0}", reader.GetValue(3)).ToString())
                    Form2.accno.Text = "Account Number: " + (String.Format("{0}", reader1.GetValue(0)).ToString())
                    c_id = cnotextBox1.Text
                    ac_no = reader1.GetValue(0).ToString()
                    custname = reader1.GetValue(1).ToString()
                    cnotextBox1.Text = ""
                    pnotextBox2.Text = ""
                    reader1.Close()

                End If


            Else
                MsgBox("Error!!!! Invalid Card No./Pin No.", MsgBoxStyle.Critical)
            End If


        End If




    End Sub

    Private Sub Clearbutton_Click(sender As Object, e As EventArgs) Handles clearbutton.Click
        pnotextBox2.Text = ""
        cnotextBox1.Text = ""
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Me.Hide()
        Adminlogin.Show()
    End Sub
End Class
