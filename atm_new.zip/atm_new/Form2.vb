﻿
Imports System.Data
Imports System.Data.SqlClient
Imports MySql.Data.MySqlClient
Imports System.DateTime

Public Class Form2

    Private Sub TextBox1_TextChanged(sender As Object, e As EventArgs)

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim query1 As String
        Dim query2 As String
        Dim cmd1 As MySqlCommand
        Dim reader1 As MySqlDataReader
        Me.Hide()
        balanceview.Show()
        balanceview.namee.Text = (String.Format("Welcome {0}", custname).ToString())
        balanceview.accountnumber.Text = "Account Number: " + (String.Format("{0}", ac_no).ToString())
        query1 = "select * from account where C_id ='" & c_id & "'"
        cmd1 = New MySqlCommand(query1, conn)
        reader1 = cmd1.ExecuteReader
        If reader1.Read = True Then
            balanceview.balance.Text = (String.Format("Current Balance: {0} ", reader1.GetValue(3)).ToString())
            reader1.Close()
            Dim time As DateTime = DateTime.Now
            Dim mode As String = "Balance_View"
            Dim oid As Integer = 100
            Randomize()
            Dim i As Integer = CInt(Int((55 * Rnd()) + 8))
            Dim randomvalue1 As Integer = CInt(Int((999 * Rnd()) + 11))       'generate random numbers between 11 and 99
            oid = (oid + randomvalue1 + i)
            query2 = "insert into operates(O_id,C_id,A_no,Sys_id,Time,Mode) values('" & oid & "','" & c_id & "','" & ac_no & "','" & sysid & "','" & time.ToString() & "','" & mode & "')"
            '  query2 = "insert into operates(C_id,A_no,Sys_id,Time,Mode) values('" & c_id & "','" & ac_no & "','" & sysid & "','" & time.ToString() & "','" & balancev & "')"
            cmd1 = New MySqlCommand(query2, conn)
            reader1 = cmd1.ExecuteReader
            '         MsgBox(query2)
            reader1.Close()
        End If


    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Withdraw.Click

        Me.Hide()
        withdrawform.Show()
        withdrawform.namee1.Text = (String.Format("Welcome {0}", custname).ToString())
        withdrawform.accountnumber1.Text = "Account Number: " + (String.Format("{0}", ac_no).ToString())

    End Sub

    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles Button5.Click

        Me.Hide()
        deposit.Show()
        deposit.welcome.Text = (String.Format("Welcome {0}", custname).ToString())
        deposit.accno.Text = "Account Number: " + (String.Format("{0}", ac_no).ToString())
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        Me.Hide()
        fundtransfer.Show()
        fundtransfer.welcome.Text = (String.Format("Welcome {0}", custname).ToString())


        ' fundtransfer.accno.Text = "Account Number: " + (String.Format("{0}", ac_no).ToString())
    End Sub

    Private Sub Logoutbutton_Click(sender As Object, e As EventArgs) Handles logoutbutton.Click

        Me.Hide()
        conn.Close()
        Form1.Show()
        MsgBox("Logged out Successfully!!", MsgBoxStyle.OkOnly, "Log Out")

    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Me.Hide()
        changepin.Show()
        changepin.welcome.Text = (String.Format("Welcome {0}", custname).ToString())

    End Sub

    Private Sub Logs_Click(sender As Object, e As EventArgs) Handles logs.Click
        Me.Hide()
        transactionlogs.Show()
        transactionlogs.welcome.Text = (String.Format("Welcome {0}", custname).ToString())
    End Sub
End Class