﻿Imports System.Data
Imports System.Data.SqlClient
Imports MySql.Data.MySqlClient

Module login

    Public conn As New MySqlConnection
    Public cmd As New MySqlCommand
    Public reader As MySqlDataReader
    Public ds As New DataSet


    Public query, user, name1 As String
    Public ac_no As String
    Public c_id As String
    Public custname As String
    Public empname As String
    Public empid As String
    Public sysid As String = "camsid123"
    Public operatesid As Integer = 0
    Public transferbal As Integer                    'transferbalanace amount
    Public transferaccountno As String              'transfer account number


End Module
