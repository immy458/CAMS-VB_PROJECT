﻿Imports MySql.Data.MySqlClient
Public Class Adminwelcomeform
    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Me.Hide()
        employeecheckbalance.Show()
        employeecheckbalance.welcome.Text = (String.Format("Welcome {0}", empname).ToString())
        Dim query1 As String
        Dim query2 As String
        Dim cmd1 As MySqlCommand
        Dim reader1 As MySqlDataReader
        query1 = "select * from cams where Sys_id ='" & sysid & "'"
        cmd1 = New MySqlCommand(query1, conn)
        reader1 = cmd1.ExecuteReader
        If reader1.Read = True Then
            employeecheckbalance.balance.Text = (String.Format("Current Balance: {0} ", reader1.GetValue(2)).ToString())
            reader1.Close()
            Dim time As DateTime = DateTime.Now
            Dim mode As String = "Balance_View"
            Dim oid As Integer = 100
            Randomize()
            Dim i As Integer = CInt(Int((55 * Rnd()) + 8))
            Dim randomvalue1 As Integer = CInt(Int((999 * Rnd()) + 11))       'generate random numbers between 11 and 99
            oid = (oid + randomvalue1 + i)
            query2 = "insert into managed_by(mid,Sys_id,Eid,Time,Mode) values('" & oid & "','" & sysid & "','" & empid & "','" & time.ToString() & "','" & mode & "')"
            cmd1 = New MySqlCommand(query2, conn)
            reader1 = cmd1.ExecuteReader
            ' MsgBox(query2)
            reader1.Close()
        End If

    End Sub

    Private Sub Logoutbutton_Click(sender As Object, e As EventArgs) Handles logoutbutton.Click
        Me.Hide()
        conn.Close()
        Form1.Show()
        MsgBox("Logged out Successfully!!", MsgBoxStyle.OkOnly, "Log Out")
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles employeewithdraw.Click
        Me.Hide()
        employeewithdrawform.Show()
        employeewithdrawform.namee1.Text = (String.Format("Welcome {0}", empname).ToString())

    End Sub

    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles employeecashdeposit.Click
        Me.Hide()
        employeedepositmoney.Show()
        employeedepositmoney.welcome.Text = (String.Format("Welcome {0}", empname).ToString())
    End Sub
End Class