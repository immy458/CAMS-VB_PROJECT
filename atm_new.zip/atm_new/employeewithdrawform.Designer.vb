﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class employeewithdrawform
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.amounttextbox = New System.Windows.Forms.TextBox()
        Me.backbutton = New System.Windows.Forms.Button()
        Me.proceedbutton = New System.Windows.Forms.Button()
        Me.cno = New System.Windows.Forms.Label()
        Me.namee1 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'amounttextbox
        '
        Me.amounttextbox.BackColor = System.Drawing.Color.White
        Me.amounttextbox.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.amounttextbox.Location = New System.Drawing.Point(376, 276)
        Me.amounttextbox.Name = "amounttextbox"
        Me.amounttextbox.Size = New System.Drawing.Size(252, 38)
        Me.amounttextbox.TabIndex = 25
        '
        'backbutton
        '
        Me.backbutton.BackColor = System.Drawing.Color.White
        Me.backbutton.FlatAppearance.BorderColor = System.Drawing.Color.White
        Me.backbutton.FlatAppearance.BorderSize = 4
        Me.backbutton.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.backbutton.Font = New System.Drawing.Font("Cooper Black", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.backbutton.ForeColor = System.Drawing.Color.ForestGreen
        Me.backbutton.Location = New System.Drawing.Point(294, 421)
        Me.backbutton.Name = "backbutton"
        Me.backbutton.Size = New System.Drawing.Size(107, 49)
        Me.backbutton.TabIndex = 24
        Me.backbutton.Text = "GO BACK"
        Me.backbutton.UseVisualStyleBackColor = False
        '
        'proceedbutton
        '
        Me.proceedbutton.BackColor = System.Drawing.Color.White
        Me.proceedbutton.FlatAppearance.BorderColor = System.Drawing.Color.White
        Me.proceedbutton.FlatAppearance.BorderSize = 4
        Me.proceedbutton.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.proceedbutton.Font = New System.Drawing.Font("Cooper Black", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.proceedbutton.ForeColor = System.Drawing.Color.ForestGreen
        Me.proceedbutton.Location = New System.Drawing.Point(629, 421)
        Me.proceedbutton.Name = "proceedbutton"
        Me.proceedbutton.Size = New System.Drawing.Size(107, 49)
        Me.proceedbutton.TabIndex = 23
        Me.proceedbutton.Text = "PROCEED"
        Me.proceedbutton.UseVisualStyleBackColor = False
        '
        'cno
        '
        Me.cno.AutoSize = True
        Me.cno.Font = New System.Drawing.Font("Copperplate Gothic Bold", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cno.ForeColor = System.Drawing.Color.DarkRed
        Me.cno.Location = New System.Drawing.Point(97, 266)
        Me.cno.MaximumSize = New System.Drawing.Size(250, 0)
        Me.cno.Name = "cno"
        Me.cno.Size = New System.Drawing.Size(248, 52)
        Me.cno.TabIndex = 22
        Me.cno.Text = "Enter Amount to Withdraw"
        '
        'namee1
        '
        Me.namee1.AutoSize = True
        Me.namee1.Font = New System.Drawing.Font("Copperplate Gothic Bold", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.namee1.ForeColor = System.Drawing.Color.DarkOrange
        Me.namee1.Location = New System.Drawing.Point(238, 89)
        Me.namee1.Name = "namee1"
        Me.namee1.Size = New System.Drawing.Size(126, 31)
        Me.namee1.TabIndex = 20
        Me.namee1.Text = "Label1"
        Me.namee1.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Label1.Font = New System.Drawing.Font("Corbel", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.White
        Me.Label1.Location = New System.Drawing.Point(416, 176)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(142, 29)
        Me.Label1.TabIndex = 26
        Me.Label1.Text = "WITHDRAW"
        '
        'Label2
        '
        Me.Label2.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label2.AutoSize = True
        Me.Label2.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Label2.Font = New System.Drawing.Font("Copperplate Gothic Bold", 19.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.DodgerBlue
        Me.Label2.Location = New System.Drawing.Point(424, 9)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(158, 38)
        Me.Label2.TabIndex = 46
        Me.Label2.Text = "C A M S"
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'employeewithdrawform
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = Global.atm_new.My.Resources.Resources.image2
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(969, 576)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.amounttextbox)
        Me.Controls.Add(Me.backbutton)
        Me.Controls.Add(Me.proceedbutton)
        Me.Controls.Add(Me.cno)
        Me.Controls.Add(Me.namee1)
        Me.Name = "employeewithdrawform"
        Me.Text = "employeewithdrawform"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Private WithEvents amounttextbox As TextBox
    Private WithEvents backbutton As Button
    Private WithEvents proceedbutton As Button
    Private WithEvents cno As Label
    Friend WithEvents namee1 As Label
    Private WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
End Class
