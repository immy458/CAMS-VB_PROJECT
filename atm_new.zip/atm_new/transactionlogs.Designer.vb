﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class transactionlogs
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.welcome = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Withdrawhistory = New System.Windows.Forms.Button()
        Me.deposithistory = New System.Windows.Forms.Button()
        Me.transferhistory = New System.Windows.Forms.Button()
        Me.backbutton = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'welcome
        '
        Me.welcome.AutoSize = True
        Me.welcome.Font = New System.Drawing.Font("Copperplate Gothic Bold", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.welcome.ForeColor = System.Drawing.Color.DarkOrange
        Me.welcome.Location = New System.Drawing.Point(297, 111)
        Me.welcome.Name = "welcome"
        Me.welcome.Size = New System.Drawing.Size(122, 31)
        Me.welcome.TabIndex = 22
        Me.welcome.Text = "label1"
        Me.welcome.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.Label2.Font = New System.Drawing.Font("Copperplate Gothic Bold", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.MidnightBlue
        Me.Label2.Location = New System.Drawing.Point(202, 191)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(544, 26)
        Me.Label2.TabIndex = 32
        Me.Label2.Text = "PLEASE SELECT APPROPRIATE OPTION"
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Withdrawhistory
        '
        Me.Withdrawhistory.Font = New System.Drawing.Font("Copperplate Gothic Bold", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Withdrawhistory.ForeColor = System.Drawing.SystemColors.HotTrack
        Me.Withdrawhistory.Location = New System.Drawing.Point(76, 267)
        Me.Withdrawhistory.Name = "Withdrawhistory"
        Me.Withdrawhistory.Size = New System.Drawing.Size(221, 56)
        Me.Withdrawhistory.TabIndex = 33
        Me.Withdrawhistory.Text = "WITHDRAWAL HISTORY"
        Me.Withdrawhistory.UseVisualStyleBackColor = True
        '
        'deposithistory
        '
        Me.deposithistory.Font = New System.Drawing.Font("Copperplate Gothic Bold", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.deposithistory.ForeColor = System.Drawing.SystemColors.HotTrack
        Me.deposithistory.Location = New System.Drawing.Point(655, 300)
        Me.deposithistory.Name = "deposithistory"
        Me.deposithistory.Size = New System.Drawing.Size(221, 56)
        Me.deposithistory.TabIndex = 34
        Me.deposithistory.Text = "DEPOSIT  HISTORY"
        Me.deposithistory.UseVisualStyleBackColor = True
        '
        'transferhistory
        '
        Me.transferhistory.Font = New System.Drawing.Font("Copperplate Gothic Bold", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.transferhistory.ForeColor = System.Drawing.SystemColors.HotTrack
        Me.transferhistory.Location = New System.Drawing.Point(76, 383)
        Me.transferhistory.Name = "transferhistory"
        Me.transferhistory.Size = New System.Drawing.Size(221, 56)
        Me.transferhistory.TabIndex = 35
        Me.transferhistory.Text = "TRANSFER HISTORY"
        Me.transferhistory.UseVisualStyleBackColor = True
        '
        'backbutton
        '
        Me.backbutton.BackColor = System.Drawing.Color.White
        Me.backbutton.FlatAppearance.BorderColor = System.Drawing.Color.White
        Me.backbutton.FlatAppearance.BorderSize = 4
        Me.backbutton.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.backbutton.Font = New System.Drawing.Font("Cooper Black", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.backbutton.ForeColor = System.Drawing.Color.Red
        Me.backbutton.Location = New System.Drawing.Point(423, 475)
        Me.backbutton.Name = "backbutton"
        Me.backbutton.Size = New System.Drawing.Size(107, 49)
        Me.backbutton.TabIndex = 36
        Me.backbutton.Text = "GO BACK"
        Me.backbutton.UseVisualStyleBackColor = False
        '
        'Label1
        '
        Me.Label1.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Label1.Font = New System.Drawing.Font("Copperplate Gothic Bold", 19.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.DodgerBlue
        Me.Label1.Location = New System.Drawing.Point(406, 9)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(158, 38)
        Me.Label1.TabIndex = 44
        Me.Label1.Text = "C A M S"
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'transactionlogs
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = Global.atm_new.My.Resources.Resources.image2
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(969, 576)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.backbutton)
        Me.Controls.Add(Me.transferhistory)
        Me.Controls.Add(Me.deposithistory)
        Me.Controls.Add(Me.Withdrawhistory)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.welcome)
        Me.Name = "transactionlogs"
        Me.Text = "Form3"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents welcome As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Withdrawhistory As Button
    Friend WithEvents deposithistory As Button
    Friend WithEvents transferhistory As Button
    Private WithEvents backbutton As Button
    Friend WithEvents Label1 As Label
End Class
