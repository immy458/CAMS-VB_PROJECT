﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class employeedepositmoney
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.welcome = New System.Windows.Forms.Label()
        Me.cno = New System.Windows.Forms.Label()
        Me.backbutton = New System.Windows.Forms.Button()
        Me.amounttextbox2 = New System.Windows.Forms.TextBox()
        Me.proceedbutton = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'welcome
        '
        Me.welcome.AutoSize = True
        Me.welcome.BackColor = System.Drawing.SystemColors.Control
        Me.welcome.Font = New System.Drawing.Font("Copperplate Gothic Bold", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.welcome.ForeColor = System.Drawing.Color.DarkOrange
        Me.welcome.Location = New System.Drawing.Point(262, 90)
        Me.welcome.Name = "welcome"
        Me.welcome.Size = New System.Drawing.Size(126, 31)
        Me.welcome.TabIndex = 14
        Me.welcome.Text = "Label1"
        Me.welcome.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'cno
        '
        Me.cno.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.cno.AutoSize = True
        Me.cno.Font = New System.Drawing.Font("Copperplate Gothic Bold", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cno.ForeColor = System.Drawing.Color.DarkRed
        Me.cno.Location = New System.Drawing.Point(76, 310)
        Me.cno.MaximumSize = New System.Drawing.Size(250, 0)
        Me.cno.Name = "cno"
        Me.cno.Size = New System.Drawing.Size(248, 52)
        Me.cno.TabIndex = 41
        Me.cno.Text = "Enter Amount to Deposit"
        '
        'backbutton
        '
        Me.backbutton.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.backbutton.BackColor = System.Drawing.Color.White
        Me.backbutton.FlatAppearance.BorderColor = System.Drawing.Color.White
        Me.backbutton.FlatAppearance.BorderSize = 4
        Me.backbutton.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.backbutton.Font = New System.Drawing.Font("Cooper Black", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.backbutton.ForeColor = System.Drawing.Color.Red
        Me.backbutton.Location = New System.Drawing.Point(355, 420)
        Me.backbutton.Name = "backbutton"
        Me.backbutton.Size = New System.Drawing.Size(107, 50)
        Me.backbutton.TabIndex = 40
        Me.backbutton.Text = "GO BACK"
        Me.backbutton.UseVisualStyleBackColor = False
        '
        'amounttextbox2
        '
        Me.amounttextbox2.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.amounttextbox2.BackColor = System.Drawing.Color.White
        Me.amounttextbox2.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.amounttextbox2.Location = New System.Drawing.Point(355, 310)
        Me.amounttextbox2.Name = "amounttextbox2"
        Me.amounttextbox2.Size = New System.Drawing.Size(339, 38)
        Me.amounttextbox2.TabIndex = 39
        '
        'proceedbutton
        '
        Me.proceedbutton.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.proceedbutton.BackColor = System.Drawing.Color.White
        Me.proceedbutton.FlatAppearance.BorderColor = System.Drawing.Color.White
        Me.proceedbutton.FlatAppearance.BorderSize = 4
        Me.proceedbutton.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.proceedbutton.Font = New System.Drawing.Font("Cooper Black", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.proceedbutton.ForeColor = System.Drawing.Color.ForestGreen
        Me.proceedbutton.Location = New System.Drawing.Point(599, 420)
        Me.proceedbutton.Name = "proceedbutton"
        Me.proceedbutton.Size = New System.Drawing.Size(107, 50)
        Me.proceedbutton.TabIndex = 38
        Me.proceedbutton.Text = "PROCEED"
        Me.proceedbutton.UseVisualStyleBackColor = False
        '
        'Label1
        '
        Me.Label1.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Label1.Font = New System.Drawing.Font("Corbel", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.White
        Me.Label1.Location = New System.Drawing.Point(428, 198)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(177, 29)
        Me.Label1.TabIndex = 42
        Me.Label1.Text = "CASH DEPOSIT"
        '
        'Label2
        '
        Me.Label2.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label2.AutoSize = True
        Me.Label2.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Label2.Font = New System.Drawing.Font("Copperplate Gothic Bold", 19.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.DodgerBlue
        Me.Label2.Location = New System.Drawing.Point(426, 9)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(158, 38)
        Me.Label2.TabIndex = 43
        Me.Label2.Text = "C A M S"
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'employeedepositmoney
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = Global.atm_new.My.Resources.Resources.image2
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(969, 576)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.cno)
        Me.Controls.Add(Me.backbutton)
        Me.Controls.Add(Me.amounttextbox2)
        Me.Controls.Add(Me.proceedbutton)
        Me.Controls.Add(Me.welcome)
        Me.Name = "employeedepositmoney"
        Me.Text = "Form3"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents welcome As Label
    Private WithEvents cno As Label
    Private WithEvents backbutton As Button
    Private WithEvents amounttextbox2 As TextBox
    Private WithEvents proceedbutton As Button
    Private WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
End Class
