﻿Imports MySql.Data.MySqlClient

Public Class fundtransfer2


    Private Sub Backbutton_Click(sender As Object, e As EventArgs) Handles backbutton.Click
        Me.Hide()
        Form2.Show()
    End Sub

    Private Sub Proceedbutton_Click(sender As Object, e As EventArgs) Handles proceedbutton.Click
        '---------------------------------------------------------withdraw code----------------------------------------
        Dim query2 As String
        Dim query1 As String
        Dim cmd1 As MySqlCommand
        Dim cmd2 As MySqlCommand

        Dim reader1 As MySqlDataReader
        Dim reader2 As MySqlDataReader

        Dim accbalance As Integer
        query1 = "select * from account where C_id ='" & c_id & "'"
        cmd1 = New MySqlCommand(query1, conn)
        reader1 = cmd1.ExecuteReader
        If reader1.Read = True Then
            accbalance = reader1.GetValue(3)
            reader1.Close()
            accbalance = accbalance - transferbal
            query2 = "update account set Balance='" & accbalance & "' where C_id ='" & c_id & "'"
            cmd2 = New MySqlCommand(query2, conn)
            reader2 = cmd2.ExecuteReader
            reader2.Close()
        End If
        '-------------------------------------------------------deposit code---------------------------------------------
        Dim accbalance2 As Integer
        query1 = "select * from account where Ac_no ='" & transferaccountno & "'"
        cmd1 = New MySqlCommand(query1, conn)
        reader1 = cmd1.ExecuteReader
        If reader1.Read = True Then
            accbalance2 = reader1.GetValue(3)
            reader1.Close()
            accbalance2 = accbalance2 + transferbal
            query2 = "update account set Balance='" & accbalance2 & "' where Ac_no ='" & transferaccountno & "'"
            cmd2 = New MySqlCommand(query2, conn)
            reader2 = cmd2.ExecuteReader
            reader2.Close()
        End If
        MessageBox.Show("Amount Transferred Successfully!!!!")

        '  ---------------------------------------------------------insert into operates-----------------------------------------------------------
        Dim time As DateTime = DateTime.Now
        Dim mode As String = "Transfer"
        Dim oid As Integer = 100
        Randomize()
        Dim i As Integer = CInt(Int((300 * Rnd()) + 200))

        Dim randomvalue1 As Integer = CInt(Int((9999 * Rnd()) + 2222))       'generate random numbers between 222 and 999
        oid = (oid + randomvalue1 + i)
        query2 = "insert into operates(O_id,C_id,A_no,Sys_id,Time,Mode) values('" & oid & "','" & c_id & "','" & ac_no & "','" & sysid & "','" & time.ToString() & "','" & mode & "')"
        cmd1 = New MySqlCommand(query2, conn)
        reader1 = cmd1.ExecuteReader
        reader1.Close()

        '---------------------------------------------------insert into transfer-----------------------------------------------------------------
        Dim ttid As Integer = 1200
        Randomize()
        Dim i1 As Integer = CInt(Int((200 * Rnd()) + 100))
        Dim randomvalue As Integer = CInt(Int((9999 * Rnd()) + 1111))       'generate random numbers between 111 and 999
        ttid = (ttid + randomvalue + i1)
        Dim date1 As DateTime = DateTime.Now
        query2 = "insert into transfer(Transfer_id,AmountTransferred,Time,Date,TransferredToAcNo) values('" & ttid & "','" & transferbal & "','" & Now.ToLongTimeString() & "','" & date1.ToString("yyyy-MM-dd") & "','" & transferaccountno & "')"
        cmd1 = New MySqlCommand(query2, conn)
        reader1 = cmd1.ExecuteReader
        reader1.Close()

        '------------------------------------------------------------------insert into performs-------------------------------------------------------------
        Dim pid As Integer = 50
        Randomize()
        Dim i2 As Integer = CInt(Int((200 * Rnd()) + 100))
        Dim pidrandomvalue As Integer = CInt(Int((99 * Rnd()) + 11))       'generate random numbers between 111 and 999
        pid = (pid + pidrandomvalue + i2)
        query2 = "insert into performs(pid,Sys_id,C_id,Transfer_id) values('" & pid & "','" & sysid & "','" & c_id & "','" & ttid & "')"
        cmd1 = New MySqlCommand(query2, conn)
        reader1 = cmd1.ExecuteReader
        reader1.Close()


        Me.Hide()
        Form2.Show()

    End Sub
End Class