﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.clearbutton = New System.Windows.Forms.Button()
        Me.loginbutton = New System.Windows.Forms.Button()
        Me.pnotextBox2 = New System.Windows.Forms.TextBox()
        Me.pin = New System.Windows.Forms.Label()
        Me.cnotextBox1 = New System.Windows.Forms.TextBox()
        Me.cno = New System.Windows.Forms.Label()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'clearbutton
        '
        Me.clearbutton.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.clearbutton.BackColor = System.Drawing.Color.White
        Me.clearbutton.FlatAppearance.BorderColor = System.Drawing.Color.White
        Me.clearbutton.FlatAppearance.BorderSize = 4
        Me.clearbutton.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.clearbutton.Font = New System.Drawing.Font("Cooper Black", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.clearbutton.ForeColor = System.Drawing.Color.Red
        Me.clearbutton.Location = New System.Drawing.Point(336, 458)
        Me.clearbutton.Name = "clearbutton"
        Me.clearbutton.Size = New System.Drawing.Size(107, 49)
        Me.clearbutton.TabIndex = 16
        Me.clearbutton.Text = "CLEAR"
        Me.clearbutton.UseVisualStyleBackColor = False
        '
        'loginbutton
        '
        Me.loginbutton.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.loginbutton.BackColor = System.Drawing.Color.White
        Me.loginbutton.FlatAppearance.BorderColor = System.Drawing.Color.White
        Me.loginbutton.FlatAppearance.BorderSize = 4
        Me.loginbutton.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.loginbutton.Font = New System.Drawing.Font("Cooper Black", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.loginbutton.ForeColor = System.Drawing.Color.ForestGreen
        Me.loginbutton.Location = New System.Drawing.Point(568, 458)
        Me.loginbutton.Name = "loginbutton"
        Me.loginbutton.Size = New System.Drawing.Size(107, 49)
        Me.loginbutton.TabIndex = 15
        Me.loginbutton.Text = "LOGIN"
        Me.loginbutton.UseVisualStyleBackColor = False
        '
        'pnotextBox2
        '
        Me.pnotextBox2.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.pnotextBox2.BackColor = System.Drawing.Color.White
        Me.pnotextBox2.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.pnotextBox2.Location = New System.Drawing.Point(336, 314)
        Me.pnotextBox2.Name = "pnotextBox2"
        Me.pnotextBox2.PasswordChar = Global.Microsoft.VisualBasic.ChrW(42)
        Me.pnotextBox2.Size = New System.Drawing.Size(339, 38)
        Me.pnotextBox2.TabIndex = 14
        '
        'pin
        '
        Me.pin.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.pin.AutoSize = True
        Me.pin.Font = New System.Drawing.Font("Cooper Std Black", 14.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.pin.ForeColor = System.Drawing.Color.DarkRed
        Me.pin.Location = New System.Drawing.Point(183, 321)
        Me.pin.Name = "pin"
        Me.pin.Size = New System.Drawing.Size(61, 29)
        Me.pin.TabIndex = 13
        Me.pin.Text = "PIN"
        '
        'cnotextBox1
        '
        Me.cnotextBox1.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.cnotextBox1.BackColor = System.Drawing.Color.White
        Me.cnotextBox1.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cnotextBox1.Location = New System.Drawing.Point(336, 227)
        Me.cnotextBox1.Name = "cnotextBox1"
        Me.cnotextBox1.Size = New System.Drawing.Size(339, 38)
        Me.cnotextBox1.TabIndex = 12
        '
        'cno
        '
        Me.cno.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.cno.AutoSize = True
        Me.cno.Font = New System.Drawing.Font("Cooper Std Black", 14.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cno.ForeColor = System.Drawing.Color.DarkRed
        Me.cno.Location = New System.Drawing.Point(183, 234)
        Me.cno.Name = "cno"
        Me.cno.Size = New System.Drawing.Size(126, 29)
        Me.cno.TabIndex = 11
        Me.cno.Text = "Card No."
        '
        'Button1
        '
        Me.Button1.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button1.BackColor = System.Drawing.Color.White
        Me.Button1.FlatAppearance.BorderColor = System.Drawing.Color.White
        Me.Button1.FlatAppearance.BorderSize = 4
        Me.Button1.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Button1.Font = New System.Drawing.Font("Corbel", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button1.ForeColor = System.Drawing.Color.ForestGreen
        Me.Button1.Location = New System.Drawing.Point(2, 7)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(183, 47)
        Me.Button1.TabIndex = 17
        Me.Button1.Text = "CLICK FOR EMPLOYEE LOGIN"
        Me.Button1.UseVisualStyleBackColor = False
        '
        'Label1
        '
        Me.Label1.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Label1.Font = New System.Drawing.Font("Corbel", 16.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.White
        Me.Label1.Location = New System.Drawing.Point(439, 126)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(97, 35)
        Me.Label1.TabIndex = 26
        Me.Label1.Text = "LOGIN"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Label2.Font = New System.Drawing.Font("Copperplate Gothic Bold", 22.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.DodgerBlue
        Me.Label2.Location = New System.Drawing.Point(283, 11)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(416, 43)
        Me.Label2.TabIndex = 27
        Me.Label2.Text = "Welcome To CAMS"
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = Global.atm_new.My.Resources.Resources.image2
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(938, 576)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.clearbutton)
        Me.Controls.Add(Me.loginbutton)
        Me.Controls.Add(Me.pnotextBox2)
        Me.Controls.Add(Me.pin)
        Me.Controls.Add(Me.cnotextBox1)
        Me.Controls.Add(Me.cno)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Private WithEvents clearbutton As Button
    Private WithEvents loginbutton As Button
    Private WithEvents pnotextBox2 As TextBox
    Private WithEvents pin As Label
    Private WithEvents cnotextBox1 As TextBox
    Private WithEvents cno As Label
    Private WithEvents Button1 As Button
    Private WithEvents Label1 As Label
    Private WithEvents Label2 As Label
End Class
