﻿Public Class balanceview
    Private Sub Form3_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub Backbutton_Click(sender As Object, e As EventArgs) Handles backbutton.Click
        Me.Hide()
        Form2.Show()
    End Sub

    Private Sub Logoutbutton_Click(sender As Object, e As EventArgs) Handles logoutbutton.Click
        Me.Hide()

        Form1.Show()
        MessageBox.Show("Logged out Successfully!!")
    End Sub
End Class