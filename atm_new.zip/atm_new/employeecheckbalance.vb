﻿Public Class employeecheckbalance
    Private Sub Backbutton_Click(sender As Object, e As EventArgs) Handles backbutton.Click
        Me.Hide()
        Adminwelcomeform.Show()

    End Sub

    Private Sub Employeecheckbalance_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class