﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class balanceview
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.namee = New System.Windows.Forms.Label()
        Me.accountnumber = New System.Windows.Forms.Label()
        Me.balance = New System.Windows.Forms.Label()
        Me.backbutton = New System.Windows.Forms.Button()
        Me.logoutbutton = New System.Windows.Forms.Button()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'namee
        '
        Me.namee.AutoSize = True
        Me.namee.Font = New System.Drawing.Font("Copperplate Gothic Bold", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.namee.ForeColor = System.Drawing.Color.DarkOrange
        Me.namee.Location = New System.Drawing.Point(267, 97)
        Me.namee.Name = "namee"
        Me.namee.Size = New System.Drawing.Size(126, 31)
        Me.namee.TabIndex = 2
        Me.namee.Text = "Label1"
        Me.namee.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'accountnumber
        '
        Me.accountnumber.AutoSize = True
        Me.accountnumber.Font = New System.Drawing.Font("Copperplate Gothic Bold", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.accountnumber.ForeColor = System.Drawing.SystemColors.HotTrack
        Me.accountnumber.Location = New System.Drawing.Point(36, 166)
        Me.accountnumber.Name = "accountnumber"
        Me.accountnumber.Size = New System.Drawing.Size(108, 26)
        Me.accountnumber.TabIndex = 3
        Me.accountnumber.Text = "Label2"
        Me.accountnumber.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'balance
        '
        Me.balance.AutoSize = True
        Me.balance.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.balance.Font = New System.Drawing.Font("Copperplate Gothic Bold", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.balance.ForeColor = System.Drawing.Color.Black
        Me.balance.Location = New System.Drawing.Point(280, 250)
        Me.balance.Name = "balance"
        Me.balance.Size = New System.Drawing.Size(134, 34)
        Me.balance.TabIndex = 4
        Me.balance.Text = "Label3"
        Me.balance.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'backbutton
        '
        Me.backbutton.BackColor = System.Drawing.Color.White
        Me.backbutton.FlatAppearance.BorderColor = System.Drawing.Color.White
        Me.backbutton.FlatAppearance.BorderSize = 4
        Me.backbutton.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.backbutton.Font = New System.Drawing.Font("Cooper Black", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.backbutton.ForeColor = System.Drawing.Color.ForestGreen
        Me.backbutton.Location = New System.Drawing.Point(286, 410)
        Me.backbutton.Name = "backbutton"
        Me.backbutton.Size = New System.Drawing.Size(107, 49)
        Me.backbutton.TabIndex = 16
        Me.backbutton.Text = "GO BACK"
        Me.backbutton.UseVisualStyleBackColor = False
        '
        'logoutbutton
        '
        Me.logoutbutton.BackColor = System.Drawing.Color.White
        Me.logoutbutton.FlatAppearance.BorderColor = System.Drawing.Color.White
        Me.logoutbutton.FlatAppearance.BorderSize = 4
        Me.logoutbutton.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.logoutbutton.Font = New System.Drawing.Font("Cooper Black", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.logoutbutton.ForeColor = System.Drawing.Color.Red
        Me.logoutbutton.Location = New System.Drawing.Point(631, 410)
        Me.logoutbutton.Name = "logoutbutton"
        Me.logoutbutton.Size = New System.Drawing.Size(107, 49)
        Me.logoutbutton.TabIndex = 17
        Me.logoutbutton.Text = "LOG OUT"
        Me.logoutbutton.UseVisualStyleBackColor = False
        '
        'Label2
        '
        Me.Label2.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label2.AutoSize = True
        Me.Label2.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Label2.Font = New System.Drawing.Font("Copperplate Gothic Bold", 19.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.DodgerBlue
        Me.Label2.Location = New System.Drawing.Point(420, 9)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(158, 38)
        Me.Label2.TabIndex = 21
        Me.Label2.Text = "C A M S"
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'balanceview
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = Global.atm_new.My.Resources.Resources.image2
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(969, 576)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.logoutbutton)
        Me.Controls.Add(Me.backbutton)
        Me.Controls.Add(Me.balance)
        Me.Controls.Add(Me.accountnumber)
        Me.Controls.Add(Me.namee)
        Me.Name = "balanceview"
        Me.Text = "Form3"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents namee As Label
    Friend WithEvents accountnumber As Label
    Friend WithEvents balance As Label
    Private WithEvents backbutton As Button
    Private WithEvents logoutbutton As Button
    Friend WithEvents Label2 As Label
End Class
