﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class payemi
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.backbutton = New System.Windows.Forms.Button()
        Me.proceedbutton = New System.Windows.Forms.Button()
        Me.cnotextBox1 = New System.Windows.Forms.TextBox()
        Me.cno = New System.Windows.Forms.Label()
        Me.accno = New System.Windows.Forms.Label()
        Me.welcome = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Copperplate Gothic Bold", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.DarkRed
        Me.Label1.Location = New System.Drawing.Point(156, 261)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(138, 26)
        Me.Label1.TabIndex = 38
        Me.Label1.Text = "Ammount"
        '
        'TextBox1
        '
        Me.TextBox1.BackColor = System.Drawing.Color.White
        Me.TextBox1.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox1.Location = New System.Drawing.Point(330, 252)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(339, 38)
        Me.TextBox1.TabIndex = 37
        '
        'backbutton
        '
        Me.backbutton.BackColor = System.Drawing.Color.White
        Me.backbutton.FlatAppearance.BorderColor = System.Drawing.Color.White
        Me.backbutton.FlatAppearance.BorderSize = 4
        Me.backbutton.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.backbutton.Font = New System.Drawing.Font("Cooper Black", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.backbutton.ForeColor = System.Drawing.Color.Red
        Me.backbutton.Location = New System.Drawing.Point(330, 351)
        Me.backbutton.Name = "backbutton"
        Me.backbutton.Size = New System.Drawing.Size(107, 49)
        Me.backbutton.TabIndex = 36
        Me.backbutton.Text = "GO BACK"
        Me.backbutton.UseVisualStyleBackColor = False
        '
        'proceedbutton
        '
        Me.proceedbutton.BackColor = System.Drawing.Color.White
        Me.proceedbutton.FlatAppearance.BorderColor = System.Drawing.Color.White
        Me.proceedbutton.FlatAppearance.BorderSize = 4
        Me.proceedbutton.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.proceedbutton.Font = New System.Drawing.Font("Cooper Black", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.proceedbutton.ForeColor = System.Drawing.Color.ForestGreen
        Me.proceedbutton.Location = New System.Drawing.Point(562, 351)
        Me.proceedbutton.Name = "proceedbutton"
        Me.proceedbutton.Size = New System.Drawing.Size(107, 49)
        Me.proceedbutton.TabIndex = 35
        Me.proceedbutton.Text = "PROCEED"
        Me.proceedbutton.UseVisualStyleBackColor = False
        '
        'cnotextBox1
        '
        Me.cnotextBox1.BackColor = System.Drawing.Color.White
        Me.cnotextBox1.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cnotextBox1.Location = New System.Drawing.Point(330, 188)
        Me.cnotextBox1.Name = "cnotextBox1"
        Me.cnotextBox1.Size = New System.Drawing.Size(339, 38)
        Me.cnotextBox1.TabIndex = 34
        '
        'cno
        '
        Me.cno.AutoSize = True
        Me.cno.Font = New System.Drawing.Font("Copperplate Gothic Bold", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cno.ForeColor = System.Drawing.Color.DarkRed
        Me.cno.Location = New System.Drawing.Point(99, 200)
        Me.cno.Name = "cno"
        Me.cno.Size = New System.Drawing.Size(195, 26)
        Me.cno.TabIndex = 33
        Me.cno.Text = "Enter Emi No."
        '
        'accno
        '
        Me.accno.AutoSize = True
        Me.accno.Font = New System.Drawing.Font("Copperplate Gothic Bold", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.accno.ForeColor = System.Drawing.SystemColors.HotTrack
        Me.accno.Location = New System.Drawing.Point(18, 78)
        Me.accno.Name = "accno"
        Me.accno.Size = New System.Drawing.Size(437, 26)
        Me.accno.TabIndex = 32
        Me.accno.Text = "ACCOUNT NUMBER: CAMS1234"
        Me.accno.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'welcome
        '
        Me.welcome.AutoSize = True
        Me.welcome.Font = New System.Drawing.Font("Copperplate Gothic Bold", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.welcome.ForeColor = System.Drawing.Color.DarkOrange
        Me.welcome.Location = New System.Drawing.Point(251, 20)
        Me.welcome.Name = "welcome"
        Me.welcome.Size = New System.Drawing.Size(358, 26)
        Me.welcome.TabIndex = 31
        Me.welcome.Text = "WELCOME IMTIYAZ KHAN"
        Me.welcome.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'payemi
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.TextBox1)
        Me.Controls.Add(Me.backbutton)
        Me.Controls.Add(Me.proceedbutton)
        Me.Controls.Add(Me.cnotextBox1)
        Me.Controls.Add(Me.cno)
        Me.Controls.Add(Me.accno)
        Me.Controls.Add(Me.welcome)
        Me.Name = "payemi"
        Me.Text = "Form3"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Private WithEvents Label1 As Label
    Private WithEvents TextBox1 As TextBox
    Private WithEvents backbutton As Button
    Private WithEvents proceedbutton As Button
    Private WithEvents cnotextBox1 As TextBox
    Private WithEvents cno As Label
    Friend WithEvents accno As Label
    Friend WithEvents welcome As Label
End Class
