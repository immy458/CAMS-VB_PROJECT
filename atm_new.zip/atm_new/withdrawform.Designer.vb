﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class withdrawform
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.namee1 = New System.Windows.Forms.Label()
        Me.accountnumber1 = New System.Windows.Forms.Label()
        Me.cno = New System.Windows.Forms.Label()
        Me.proceedbutton = New System.Windows.Forms.Button()
        Me.backbutton = New System.Windows.Forms.Button()
        Me.amounttextbox = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'namee1
        '
        Me.namee1.AutoSize = True
        Me.namee1.Font = New System.Drawing.Font("Copperplate Gothic Bold", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.namee1.ForeColor = System.Drawing.Color.DarkOrange
        Me.namee1.Location = New System.Drawing.Point(241, 84)
        Me.namee1.Name = "namee1"
        Me.namee1.Size = New System.Drawing.Size(126, 31)
        Me.namee1.TabIndex = 3
        Me.namee1.Text = "Label1"
        Me.namee1.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'accountnumber1
        '
        Me.accountnumber1.AutoSize = True
        Me.accountnumber1.Font = New System.Drawing.Font("Copperplate Gothic Bold", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.accountnumber1.ForeColor = System.Drawing.SystemColors.HotTrack
        Me.accountnumber1.Location = New System.Drawing.Point(63, 149)
        Me.accountnumber1.Name = "accountnumber1"
        Me.accountnumber1.Size = New System.Drawing.Size(108, 26)
        Me.accountnumber1.TabIndex = 4
        Me.accountnumber1.Text = "Label2"
        Me.accountnumber1.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'cno
        '
        Me.cno.AutoSize = True
        Me.cno.Font = New System.Drawing.Font("Copperplate Gothic Bold", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cno.ForeColor = System.Drawing.Color.DarkRed
        Me.cno.Location = New System.Drawing.Point(89, 293)
        Me.cno.MaximumSize = New System.Drawing.Size(250, 0)
        Me.cno.Name = "cno"
        Me.cno.Size = New System.Drawing.Size(248, 52)
        Me.cno.TabIndex = 14
        Me.cno.Text = "Enter Amount to Withdraw"
        '
        'proceedbutton
        '
        Me.proceedbutton.BackColor = System.Drawing.Color.White
        Me.proceedbutton.FlatAppearance.BorderColor = System.Drawing.Color.White
        Me.proceedbutton.FlatAppearance.BorderSize = 4
        Me.proceedbutton.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.proceedbutton.Font = New System.Drawing.Font("Cooper Black", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.proceedbutton.ForeColor = System.Drawing.Color.ForestGreen
        Me.proceedbutton.Location = New System.Drawing.Point(678, 411)
        Me.proceedbutton.Name = "proceedbutton"
        Me.proceedbutton.Size = New System.Drawing.Size(107, 49)
        Me.proceedbutton.TabIndex = 17
        Me.proceedbutton.Text = "PROCEED"
        Me.proceedbutton.UseVisualStyleBackColor = False
        '
        'backbutton
        '
        Me.backbutton.BackColor = System.Drawing.Color.White
        Me.backbutton.FlatAppearance.BorderColor = System.Drawing.Color.White
        Me.backbutton.FlatAppearance.BorderSize = 4
        Me.backbutton.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.backbutton.Font = New System.Drawing.Font("Cooper Black", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.backbutton.ForeColor = System.Drawing.Color.ForestGreen
        Me.backbutton.Location = New System.Drawing.Point(351, 411)
        Me.backbutton.Name = "backbutton"
        Me.backbutton.Size = New System.Drawing.Size(107, 49)
        Me.backbutton.TabIndex = 18
        Me.backbutton.Text = "GO BACK"
        Me.backbutton.UseVisualStyleBackColor = False
        '
        'amounttextbox
        '
        Me.amounttextbox.BackColor = System.Drawing.Color.White
        Me.amounttextbox.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.amounttextbox.Location = New System.Drawing.Point(405, 293)
        Me.amounttextbox.Name = "amounttextbox"
        Me.amounttextbox.Size = New System.Drawing.Size(292, 38)
        Me.amounttextbox.TabIndex = 19
        '
        'Label2
        '
        Me.Label2.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label2.AutoSize = True
        Me.Label2.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Label2.Font = New System.Drawing.Font("Copperplate Gothic Bold", 19.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.DodgerBlue
        Me.Label2.Location = New System.Drawing.Point(390, 9)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(158, 38)
        Me.Label2.TabIndex = 20
        Me.Label2.Text = "C A M S"
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'Label1
        '
        Me.Label1.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Label1.Font = New System.Drawing.Font("Corbel", 16.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.White
        Me.Label1.Location = New System.Drawing.Point(466, 210)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(163, 35)
        Me.Label1.TabIndex = 27
        Me.Label1.Text = "WITHDRAW"
        '
        'withdrawform
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = Global.atm_new.My.Resources.Resources.image2
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(938, 576)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.amounttextbox)
        Me.Controls.Add(Me.backbutton)
        Me.Controls.Add(Me.proceedbutton)
        Me.Controls.Add(Me.cno)
        Me.Controls.Add(Me.accountnumber1)
        Me.Controls.Add(Me.namee1)
        Me.Name = "withdrawform"
        Me.Text = "Form4"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents namee1 As Label
    Friend WithEvents accountnumber1 As Label
    Private WithEvents cno As Label
    Private WithEvents proceedbutton As Button
    Private WithEvents backbutton As Button
    Private WithEvents amounttextbox As TextBox
    Friend WithEvents Label2 As Label
    Private WithEvents Label1 As Label
End Class
