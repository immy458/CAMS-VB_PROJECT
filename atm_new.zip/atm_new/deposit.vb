﻿Imports MySql.Data.MySqlClient

Public Class deposit
    Private Sub Proceedbutton_Click(sender As Object, e As EventArgs) Handles proceedbutton.Click
        If (amounttextbox2.Text = "") Then
            MessageBox.Show("Please enter amount!!")


        Else
            Dim bal As Integer
        bal = amounttextbox2.Text
            If ((bal <= 0)) Then
                MsgBox("Amount cannot be less than or equal to 0", MsgBoxStyle.OkOnly, "Invalid Amount")
                amounttextbox2.Text = ""
            ElseIf (((bal Mod 100) <> 0)) Then
                MsgBox("Amount should be in multiples of 100", MsgBoxStyle.OkOnly, "Invalid Amount")
                amounttextbox2.Text = ""
            ElseIf ((bal > 15000)) Then
                MsgBox(" Maximum deposit limit is 15000!!", MsgBoxStyle.OkOnly, "Invalid Amount")

                amounttextbox2.Text = ""
            Else
                Dim query2 As String
                Dim query1 As String
                Dim query3 As String
                Dim cmd1 As MySqlCommand
                Dim cmd2 As MySqlCommand
                Dim cmd3 As MySqlCommand

                Dim newsysbalance As Integer

                Dim reader1 As MySqlDataReader
                Dim reader2 As MySqlDataReader
                Dim reader3 As MySqlDataReader

                query3 = "select * from cams where Sys_id ='" & sysid & "'"
                cmd3 = New MySqlCommand(query3, conn)
                reader3 = cmd3.ExecuteReader
                If reader3.Read = True Then
                    newsysbalance = reader3.GetValue(2)
                    reader3.Close()
                End If

                Dim accbalance As Integer
                query1 = "select * from account where C_id ='" & c_id & "'"
                cmd1 = New MySqlCommand(query1, conn)
                reader1 = cmd1.ExecuteReader
                If reader1.Read = True Then
                    accbalance = reader1.GetValue(3)
                    reader1.Close()
                    accbalance = accbalance + bal
                    newsysbalance = newsysbalance + bal
                    query2 = "update account set Balance='" & accbalance & "' where C_id ='" & c_id & "'"
                    query3 = "update cams set Balance='" & newsysbalance & "' where Sys_id ='" & sysid & "'"
                    cmd3 = New MySqlCommand(query3, conn)
                    reader3 = cmd3.ExecuteReader
                    reader3.Close()
                    cmd2 = New MySqlCommand(query2, conn)
                    reader2 = cmd2.ExecuteReader
                    reader2.Close()
                    amounttextbox2.Text = ""

                    MsgBox("Amount Deposited Successfully", MsgBoxStyle.OkOnly, "Success")


                    '-------------------------------------------insert into operates-------------------------------------------
                    Dim time As DateTime = DateTime.Now
                    Dim mode As String = "Deposit"
                    Dim oid As Integer = 100
                    Randomize()
                    Dim i As Integer = CInt(Int((200 * Rnd()) + 100))

                    Dim randomvalue1 As Integer = CInt(Int((9999 * Rnd()) + 2222))       'generate random numbers between 222 and 999
                    oid = (oid + randomvalue1 + i)
                    query2 = "insert into operates(O_id,C_id,A_no,Sys_id,Time,Mode) values('" & oid & "','" & c_id & "','" & ac_no & "','" & sysid & "','" & time.ToString() & "','" & mode & "')"
                    cmd1 = New MySqlCommand(query2, conn)
                    reader1 = cmd1.ExecuteReader
                    reader1.Close()

                    '--------------------------------------------------insert into deposit--------------------------------------------------
                    Dim dtid As Integer = 1200
                    Randomize()
                    Dim i1 As Integer = CInt(Int((200 * Rnd()) + 100))
                    Dim randomvalue As Integer = CInt(Int((9999 * Rnd()) + 1111))       'generate random numbers between 111 and 999
                    dtid = (dtid + randomvalue + i1)
                    Dim date1 As DateTime = DateTime.Now
                    query2 = "insert into deposit(Deposit_id,AmountDeposited,Time,Date) values('" & dtid & "','" & bal & "','" & Now.ToLongTimeString() & "','" & date1.ToString("yyyy-MM-dd") & "')"
                    cmd1 = New MySqlCommand(query2, conn)
                    reader1 = cmd1.ExecuteReader
                    reader1.Close()

                    '--------------------------------------------------------insert into performs------------------------------------------------
                    Dim pid As Integer = 50
                    Randomize()
                    Dim i2 As Integer = CInt(Int((200 * Rnd()) + 100))
                    Dim pidrandomvalue As Integer = CInt(Int((99 * Rnd()) + 11))       'generate random numbers between 111 and 999
                    pid = (pid + pidrandomvalue + i2)
                    query2 = "insert into performs(pid,Sys_id,C_id,Deposit_id) values('" & pid & "','" & sysid & "','" & c_id & "','" & dtid & "')"
                    cmd1 = New MySqlCommand(query2, conn)
                    reader1 = cmd1.ExecuteReader
                    reader1.Close()

                    Me.Hide()
                    Form2.Show()
                End If
            End If
        End If
    End Sub

    Private Sub Backbutton_Click(sender As Object, e As EventArgs) Handles backbutton.Click
        Me.Hide()
        Form2.Show()
    End Sub
End Class