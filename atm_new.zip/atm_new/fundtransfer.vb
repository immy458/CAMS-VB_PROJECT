﻿Imports MySql.Data.MySqlClient

Public Class fundtransfer


    Private Sub Proceedbutton_Click(sender As Object, e As EventArgs) Handles proceedbutton.Click
        '   Dim bal As Integer
        If (amounttextbox3.Text = "") Then
            MessageBox.Show("Please enter amount!!")

        Else
            transferbal = 0
            transferbal = amounttextbox3.Text
            If ((transferbal <= 0)) Then
                MsgBox("Amount cannot be less than or equal to 0", MsgBoxStyle.OkOnly, "Invalid Amount")
                amounttextbox3.Text = ""
            ElseIf ((transferbal > 15000)) Then
                MsgBox("Error!! Maximum Transfer limit is 14000!!", MsgBoxStyle.OkOnly, "Invalid Amount")

                amounttextbox3.Text = ""
            Else
                Dim query2 As String
                Dim query1 As String
                Dim cmd1 As MySqlCommand
                Dim cmd2 As MySqlCommand

                Dim reader1 As MySqlDataReader
                Dim reader2 As MySqlDataReader
                Dim name As String



                '   Dim ano As String
                transferaccountno = acnotextbox.Text

                Dim accbalance As Integer
                query1 = "select * from account where C_id ='" & c_id & "'"
                cmd1 = New MySqlCommand(query1, conn)
                reader1 = cmd1.ExecuteReader
                If reader1.Read = True Then
                    accbalance = reader1.GetValue(3)
                    reader1.Close()
                    If (transferbal > accbalance) Then

                        MsgBox("Error!! Insufficient Balance!!", MsgBoxStyle.OkOnly, "Invalid Amount")

                        amounttextbox3.Text = ""
                    Else
                        query2 = "select Ac_name,C_id from account where Ac_no ='" & transferaccountno & "'"
                        Dim check As Integer
                        cmd2 = New MySqlCommand(query2, conn)
                        reader2 = cmd2.ExecuteReader
                        If reader2.Read = True Then
                            check = reader2.GetValue(1)
                            name = reader2.GetValue(0).ToString()
                            reader2.Close()
                            If (check = c_id) Then

                                MsgBox("Invalid Acount number!!", MsgBoxStyle.OkOnly, "Error")

                                amounttextbox3.Text = ""
                                acnotextbox.Text = ""
                            Else
                                amounttextbox3.Text = ""
                                acnotextbox.Text = ""
                                Me.Hide()
                                fundtransfer2.Show()
                                fundtransfer2.welcome.Text = (String.Format("Welcome {0}", custname).ToString())

                                fundtransfer2.transfername.Text = (String.Format(" Name: {0}", name).ToString())
                                fundtransfer2.amt.Text = (String.Format("Amount: {0}", transferbal).ToString())
                            End If
                            ' fundtransfer.accno.Text = "Account Number: " + (String.Format("{0}", ac_no).ToString())
                        Else
                            reader2.Close()
                            MsgBox("Invalid Acount number!!", MsgBoxStyle.OkOnly, "Error")
                            amounttextbox3.Text = ""
                            acnotextbox.Text = ""
                        End If
                    End If
                End If
            End If
        End If



    End Sub

    Private Sub Backbutton_Click(sender As Object, e As EventArgs) Handles backbutton.Click
        Me.Hide()
        Form2.Show()
    End Sub
End Class