﻿Imports MySql.Data.MySqlClient
Public Class changepin
    Private Sub Changepin_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub






    Private Sub Backbutton_Click(sender As Object, e As EventArgs) Handles backbutton.Click
        currentpin.Text = ""
        newpin.Text = ""
        Me.Hide()
        Form2.Show()

    End Sub

    Private Sub Proceedbutton_Click(sender As Object, e As EventArgs) Handles proceedbutton.Click

        Dim curpin As String
        Dim npin As String
        Dim query2 As String
        Dim query1 As String
        Dim cmd1 As MySqlCommand
        Dim cmd2 As MySqlCommand

        Dim reader1 As MySqlDataReader
        Dim reader2 As MySqlDataReader

        Dim pincheck As String
        If currentpin.Text = "" Or newpin.Text = "" Then

            MsgBox(" Card No. and Pin No. is required", MsgBoxStyle.OkOnly, "Error")

        Else
            curpin = currentpin.Text
            npin = newpin.Text

            query1 = "select C_id,C_pin from customer_details where C_id ='" & c_id & "'"
            cmd1 = New MySqlCommand(query1, conn)
            reader1 = cmd1.ExecuteReader
            If reader1.Read = True Then
                pincheck = reader1.GetValue(1)
                reader1.Close()
                If (curpin <> pincheck) Then
                    MsgBox("Incorrect Current Pin!!!!", MsgBoxStyle.OkOnly, "Error")

                    newpin.Text = ""
                    currentpin.Text = ""
                ElseIf (npin.Length() < 7 Or npin.Length() > 10) Then
                    MsgBox("Pin length should be greater than 7 and less than 10!!!", MsgBoxStyle.OkOnly, "Error")

                    newpin.Text = ""
                Else
                    query2 = "update customer_details set C_pin='" & npin & "' where C_id ='" & c_id & "'"
                    cmd2 = New MySqlCommand(query2, conn)
                    reader2 = cmd2.ExecuteReader
                    reader2.Close()
                    newpin.Text = ""
                    currentpin.Text = ""
                    MsgBox("Pin changed Successfully!!!!!", MsgBoxStyle.OkOnly, "Success")

                    Me.Hide()
                    Form2.Show()
                End If
            End If

        End If





    End Sub

End Class